//
//  NSArray+NilSafe.h
//  ArrNilSafeDemo
//
//  Created by rsh on 2018/10/16.
//  Copyright © 2018年 rsh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (NilSafe)

@end

@interface NSMutableArray (NilSafe)

@end
