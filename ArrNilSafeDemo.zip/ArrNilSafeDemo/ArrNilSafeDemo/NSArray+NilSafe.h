//
//  NSArray+NilSafe.h
//  ArrNilSafeDemo
//
//  Created by rsh on 2018/10/16.
//  Copyright © 2018年 rsh. All rights reserved.
//

#import <Foundation/Foundation.h>

//利用runtime的方法交换，重写方法，对越界的返回nil

@interface NSArray (NilSafe)


@end

