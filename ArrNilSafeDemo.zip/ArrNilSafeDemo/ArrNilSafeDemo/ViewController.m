//
//  ViewController.m
//  ArrNilSafeDemo
//
//  Created by rsh on 2018/10/16.
//  Copyright © 2018年 rsh. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    /****************--NSArray--****************/
    NSArray *arr = @[@"11",@"22",@"33",@"44",@"55"];
    NSLog(@"不可变数组越界是否崩溃：%@",arr[20]);
  
    
    
    /****************--NSMutableArray--****************/
    NSMutableArray *mutArr = [NSMutableArray arrayWithCapacity:15];
    [mutArr addObject:@"A"];
    [mutArr addObject:@"N"];
    [mutArr removeObject:@"M"];
    [mutArr addObject:nil];
    /*
     1、索引越界 2、移除索引越界 3、替换索引越界
     */
    NSLog(@"可变数组越界是否崩溃：%@",mutArr[15]);
    [mutArr removeObjectAtIndex:15];
    [mutArr replaceObjectAtIndex:15 withObject:@"Z"];
    
    NSLog(@"--------mutArr:%@",mutArr);

}



@end
