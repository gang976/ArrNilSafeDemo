//
//  AppDelegate.h
//  ArrNilSafeDemo
//
//  Created by rsh on 2018/10/16.
//  Copyright © 2018年 rsh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

