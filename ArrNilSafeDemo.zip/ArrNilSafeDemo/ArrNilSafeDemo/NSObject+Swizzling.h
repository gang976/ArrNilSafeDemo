//
//  NSObject+Swizzling.h
//  ArrNilSafeDemo
//
//  Created by rsh on 2018/10/16.
//  Copyright © 2018年 rsh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (Swizzling)


//利用runtime的交换两个方法的实现，重写方法

+ (void)swizzleSelector:(SEL)originalSelector withSwizzledSelector:(SEL)swizzledSelector;

@end
